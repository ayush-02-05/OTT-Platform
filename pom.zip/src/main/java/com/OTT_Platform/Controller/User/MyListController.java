package com.OTT_Platform.Controller.User;

import com.OTT_Platform.Model.MyList;
import com.OTT_Platform.Service.MyListService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/my-list")
public class MyListController {
    private final MyListService myListService;
    public MyListController(MyListService myListService) {
        this.myListService = myListService;
    }

    @PostMapping
    public MyList addToMyList(@RequestBody MyList myList) {
        return myListService.addToMyList(myList);
    }

    @GetMapping
    public List<MyList> getMyList(@RequestParam int userId) {
        return myListService.getMyList(userId);
    }
}
