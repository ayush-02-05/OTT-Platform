package com.OTT_Platform.Repository;

import com.OTT_Platform.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Integer> {
}
