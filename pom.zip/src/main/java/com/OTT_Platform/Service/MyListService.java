package com.OTT_Platform.Service;

import com.OTT_Platform.Model.MyList;
import com.OTT_Platform.Model.User;
import com.OTT_Platform.Repository.MyListRepository;
import com.OTT_Platform.Repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MyListService {
    private final MyListRepository myListRepository;
    private final UserRepository userRepository;
    public MyListService(MyListRepository myListRepository, UserRepository userRepository) {
        this.myListRepository = myListRepository;
        this.userRepository = userRepository;
    }

    public MyList addToMyList(MyList myList) {
        return myListRepository.save(myList);
    }

    public List<MyList> getMyList(int userId) {
        User user = userRepository.findById(userId).orElseThrow();
        return myListRepository.findByUser(user);
    }
}
