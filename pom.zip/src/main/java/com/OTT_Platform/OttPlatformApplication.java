package com.OTT_Platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OttPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(OttPlatformApplication.class, args);
		System.out.println("Hi");
	}

}